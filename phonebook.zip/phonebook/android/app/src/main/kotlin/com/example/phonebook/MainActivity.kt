package com.example.phonebook

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:firebase_database/firebase_database.dart';
import '../models/Contact.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart';

class AddContact extends StatefulWidget {
  @override
  _AddContactState createState() => _AddContactState();
}

class _AddContactState extends State<AddContact> {
  DatabaseReference _databaseReference = FirebaseDatabase.instance.reference();

  String _firstName = '';
  String _lastName = '';
  String _phone = '';
  String _email = '';
  String _address = '';
  String _photoUrl = "empty";

  saveContact(BuildContext context) async {
    if (_firstName.isNotEmpty && _lastName.isNotEmpty && _email.isNotEmpty && _email.isNotEmpty && _address.isNotEmpty && _phone.isNotEmpty){
      Contact contact = Contact(this._firstName, this._lastName, this._phone, this._email, this._address, this._photoUrl);

      await _databaseReference.push().set(contact.toJson());
      navigateToLastScreen(context);
    }else{
      showDialog(context: context,
      builder: (context){
        return AlertDialog(
          title: Text('Field Required'),
          content: Text('All Fields are required'),
          actions: [
            FlatButton(onPressed: (){
              Navigator.of(context).pop();
            },
                child: Text('Close')),
          ],
        );
      });
    }
  }

  pickImage() async {
    File file = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 200.0, maxHeight: 200.0);
    String fileName = basename(file.path);
    uploadImage(file, fileName);
  }
  uploadImage(File file,String fileName) async {
    var storageReference = FirebaseStorage.instance.ref().child(fileName); 
    storageReference.p;
  }
  
  navigateToLastScreen(context){
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
